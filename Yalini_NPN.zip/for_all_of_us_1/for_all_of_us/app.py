
from flask import Flask, request, jsonify, render_template ## Flask: to create the web application, request: to handle incoming data, jsonify: to send JSON responses, render_template: to render HTML templates
from transformers import AutoTokenizer, AutoModelForCausalLM # Import tokenizer and model for language generation
app = Flask(__name__) # Initialize the Flask application

# Load the tokenizer and model
tokenizer = AutoTokenizer.from_pretrained('gpt2')# Load the tokenizer from the pre-trained GPT-2 model
model = AutoModelForCausalLM.from_pretrained('gpt2')# Load the pre-trained GPT-2 model for causal language modeling

# Set padding token if not already set
if tokenizer.pad_token is None: # Check if the padding token is not set
    tokenizer.pad_token = tokenizer.eos_token # Set the padding token to the end-of-sequence (EOS) token (padding is to ensure all input sequences have the same length)
    tokenizer.pad_token_id = tokenizer.eos_token_id # Set the padding token ID to the EOS token ID

# Function to generate a response from the model based on user input
def generate_response(input_text, model, tokenizer):
    # Tokenize the input text into model-compatible format with padding and truncation
    inputs = tokenizer(input_text, return_tensors="pt", padding=True, truncation=True)
    # Generate a response from the model
    outputs = model.generate(
        inputs['input_ids'], # The input IDs (tokenized input text)
        attention_mask=inputs['attention_mask'],# The attention mask to ignore padded tokens
        max_length=200, # Maximum length of the generated response
        num_return_sequences=1, # Generate one response sequence
        temperature=0.7, # Sampling temperature; lower values make output more deterministic
        top_k=50,# Consider only the top 50 tokens for sampling
        top_p=0.9,# Use nucleus sampling with a cumulative probability of 0.9
        no_repeat_ngram_size=2,# Prevent repetition of 2-gram sequences in the response
        pad_token_id=tokenizer.pad_token_id,# Padding token ID
        eos_token_id=tokenizer.eos_token_id  # End-of-sequence token ID
    )
    # Decode the generated response to text
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
# If the generated response starts with the input text, remove the repetition
    if response.lower().startswith(input_text.lower()):
        response = response[len(input_text):].strip()   

     # Additional check to remove partial repetition
    if response.lower().startswith(input_text.lower().split('?')[0].strip()):
        response = response[len(input_text):].strip() 
    
    # Ensure the response ends with a period or full sentence
    if not response.endswith(('.', '!', '?')):
        response = response.rsplit('.', 1)[0] + '.' # Cut off at the last period and add a full stop if necessary

    return response
    
    
# Define the route for the homepage
@app.route('/')
def index():
    return render_template('index.html') # Render the index.html page when accessing the root URL
# Define the route for generating responses
@app.route('/get_response', methods=['POST']) #accepts POST requestsat the /get_response URL
def get_response():
    data = request.json
    user_query = data.get('query') #retrieve json data from the incoming request
    response = generate_response(user_query, model, tokenizer) #extracts query field from the json data
    return jsonify({'response': response}) #generates a response using a model
    #return jsonify({ response}) #returns response as a json object

if __name__ == '__main__':
    app.run(debug=True) #starts flask application in debug mode





